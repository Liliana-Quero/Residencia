<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TRIMESTRE extends Model
{
    use HasFactory;

    protected $table = 'trimestre';
    public $timestamps = false;
    protected $primaryKey = 'id';




    public function trimestres()
{
    return $this->hasMany(App\TRIMESTRE::class);
}

}
