<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SUCURSAL extends Model
{
    use HasFactory;


    protected $table = 'users';
    public $timestamps = false;
    protected $primaryKey = 'id';


public function trimestres()
{
    return $this->hasMany(App\TRIMESTRE::class);
}



    public function sucursales()
{
    return $this->hasMany(App\SUCURSAL::class);
}
}
