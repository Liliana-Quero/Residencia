<?php

namespace App\Http\Controllers;

use App\Http\Requests\RegisterRequest;
use Illuminate\Http\Request;

use App\Models\User;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;

class CuestionarioController extends Controller
{
    public function index(){
            $products = DB::table('products')->get();

    }
    public function cuestionario()
    {
        return view('cuestionario');
    }

    public function validar() {
        return view('cuestionario');
    }
    public function getIndex(){


        // Inicializa @rownum
   DB::statement(DB::raw('SET @rownum = 0'));

   // Realiza la consulta
      $participantes = DB::table('users')
          ->select(DB::raw('id','username', '@rownum := @rownum + 1 as rownum'));
    }
   /* public function calcularEntradas(Request $request)
    {
    $valor1 = $request->input("entrada1");
    $valor2 = $request->input("entrada2");
    $tipo   = $request->input("tipo_entrada");

switch ($tipo) {
  case "Calculo1":
    $resultado = $valor1 * 0.05 + $valor2;
    $tipo;
    break;
  case "Calculo2":
    $resultado = $valor1 * 0.085 + $valor2;
    $tipo;
    break;
  case "Calculo3":
    $resultado = $valor1 * 0.0986 + $valor2;
    $tipo;
    break;
  case "Calculo4":
    $resultado = $valor1 * 0.135 + $valor2;
    $tipo;
    break;
    default:
    echo "";
     }
    return view('cuestionario', ['tipo' => $tipo, 'resultado' => $resultado]);
  }*/
}
