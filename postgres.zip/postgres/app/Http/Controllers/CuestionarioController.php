<?php

namespace App\Http\Controllers;

use App\Http\Requests\RegisterRequest;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;

class CuestionarioController extends Controller
{

    public function cuestionario()
    {
        return view('cuestionario');
    }

    public function validar() {
        return view('cuestionario');
    }
    public function getIndex(){


        // Inicializa @rownum
   DB::statement(DB::raw('SET @rownum = 0'));

   // Realiza la consulta
      $participantes = DB::table('users')
          ->select(DB::raw('id','username', '@rownum := @rownum + 1 as rownum'));

     }
    }





