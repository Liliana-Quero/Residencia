<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class TrimestreController extends Controller
{
    public function trimestre()
    {
        return view('cuestionario');
    }





}
