<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Requests\RegisterRequest;
use App\Models\User;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    //
    public function index()
    {
        return view('home.index');
    }

    /*public function imprimirsucursal(Request $request)
    {
    $valor1 = $request->input("valorselect");
    $tipo   = $request->input("valorselect");

switch ($tipo) {

  case "valorselect":
    $resultado = $valor1;
    $tipo;
    break;
    default:
    echo "";
     }
    return view('cuestionario', ['tipo' => $tipo, 'resultado' => $resultado]);    }*/

    public function calcularEntradas(Request $request)
    {
    $valor1 = $request->input("entrada1");
    $valor2 = $request->input("entrada2");
    $tipo   = $request->input("tipo_entrada");

switch ($tipo) {
  case "Calculo1":
    $resultado = $valor1 * 0.05 + $valor2;
    $tipo;
    break;
  case "Calculo2":
    $resultado = $valor1 * 0.085 + $valor2;
    $tipo;
    break;
  case "Calculo3":
    $resultado = $valor1 * 0.0986 + $valor2;
    $tipo;
    break;
  case "Calculo4":
    $resultado = $valor1 * 0.135 + $valor2;
    $tipo;
    break;
    default:
    echo "";
     }
    return view('cuestionario', ['tipo' => $tipo, 'resultado' => $resultado]);
  }
}
