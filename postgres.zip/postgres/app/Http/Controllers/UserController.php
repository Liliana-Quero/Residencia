<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\User;
use App\Http\Requests\UsuarioFormRequest;
use App\Usuario;
use Illuminate\Support\Facades\Redirect;
use App\Http\Requests\RegisterRequest;
use App\Http\Controllers\Controller;
use App\Models\Usuario as ModelsUsuario;
use Dompdf\Adapter\PDFLib;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\pdf;


class UserController extends Controller
{
    public function __construct()
    {
        }
        public function pdf(){
            $usuarios = usuarios::paginate();
        }

        public function index(Request $request)
        {
            if ($request)
            {

                $query=trim($request->get('searchText'));
                $usuarios=DB::table('users')
                ->where('name','LIKE','%'.$query.'%')
                ->orwhere('role','=','admin')
                ->orwhere('role','LIKE','%'.$query.'%')
                ->orwhere('email','LIKE','%'.$query.'%')
                ->orderBy('id','asc')
                ->paginate(5);
                return view('usuarios',["usuarios"=>$usuarios,"searchText"=>$query]);
            }

    }
    public function store (UsuarioFormRequest $request)
    {
        $usuario=new ModelsUsuario();
        $usuario->name=$request->get('name');
        $usuario->email=$request->get('email');
        $usuario->role=$request->get('role');
        $usuario->username=$request->get('username');
        $usuario->password=$request->get('password');

        $usuario->save();
        return Redirect::to('usuarios');
    }
    public function show($id){
        return view("usuarios",["usuario"=>ModelsUsuario::findOrFail($id)]);
    }
    public function edit($id){
        return view("admin.edit",["usuario"=>ModelsUsuario::findOrFail($id)]);
    }
    public function update(UsuarioFormRequest $request, $id){
        $usuario=ModelsUsuario::findOrFail($id);
        $usuario->name=$request->get('name');
        $usuario->email=$request->get('email');
        $usuario->role=$request->get('role');
        $usuario->username=$request->get('username');
        $usuario->password=$request->get('password');
        $usuario ->update();
        return Redirect::to('usuarios');
    }
    public function destroy($id)
    {
        $usuario=ModelsUsuario::findOrFail($id);
        $usuario -> role='Inactivo';
        $usuario ->update();
        return Redirect::to('usuarios');
    }


}
