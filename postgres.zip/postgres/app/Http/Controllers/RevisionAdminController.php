<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RevisionAdminController extends Controller
{
    public function revisionadmin()
    {
        return view('revisionadmin');
    }}
