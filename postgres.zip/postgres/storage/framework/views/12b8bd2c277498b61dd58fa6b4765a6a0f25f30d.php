<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<div class="row">

        <div class="col-md" >
        <br>
                <label>

                </label>

        </div>
        <div class="col-md">
        </div>
                    <div class="col-md">
                   <br> <a href="/register"><button class="btn btn-success" style="font-size: 20px; ">
                   <img  src="<?php echo asset('images/agregar-usuario.png'); ?>" alt="usuario" width="29" height="28" style=" opacity:75%">

                   Añadir Nuevo Usuario</button></a>
                    </div>
        <h2 class="text-center"> USUARIOS:</h2>
<br>
<div class="row" style="padding: left 50px;">
    <div class="col-md-3 col-md-4 col-sm-14 col-xs-4">

      <?php echo $__env->make('admin.search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      </div>
</div><br>
</div>
<div class="row">
        <div class="col-md" >
        <br>
                <label>
                </label>

        </div>
        <div class="col-md">
        </div>
                    <div class="col-md" style="padding-left: 600px;">
                   <br> <a href="<?php echo e(route('descargar')); ?>" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
        Generar listado de usuarios (PDF)
      </a>
                    </div>
<div class="row" style="padding: left 50px;">

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="table-responsive"><BR>
            <table class="table table-striped table-bordered table-condensed table-hover">
                <thead class="text-center">
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Rol</th>
                    <th>Correo electrónico</th>
                    <th>Nombre de Usuario</th>
                 </thead>
                 <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                    <td><?php echo e($usuario->id); ?></td>
                    <td><?php echo e($usuario->name); ?></td>
                    <td><?php echo e($usuario->role); ?></td>
                    <td><?php echo e($usuario->email); ?></td>
                    <td><?php echo e($usuario->username); ?></td>

                    <td class="text-center">
                        <a href="<?php echo e(route('admin.edit', $usuario->id)); ?>" role="button" class="btn btn-info">
                            <img  src="<?php echo asset('images/editar-texto.png'); ?>" alt="usuario" width="22" height="21" style=" opacity:75%">
                            Editar</button></a>


                                <form action="<?php echo e(route('usuarios.delete', $usuario->id)); ?>" method="POST" style="display: inline-block;" onsubmit="return confirm('¿Deseas eliminar este usuario?')" >
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn btn-danger" type="submit" rel="tooltip">
                            <img  src="<?php echo asset('images/boton-salir.png'); ?>" alt="usuario" width="29" height="28" >
                            Eliminar
                        </button>

                        </form>

        </td>
				</tr>
				<?php echo $__env->make('modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
		<?php echo e($usuarios->render()); ?>

    </div>
</div>


    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php endif; ?>





    <?php if(auth()->guard()->guest()): ?>
        <h1>PANEL PROYECTO</h1>
        <p class="lead">Para ver el contenido, tienes que <a href="/login"> iniciar sesión.</a> </p>
        <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoResidencia\postgres\resources\views/usuarios.blade.php ENDPATH**/ ?>