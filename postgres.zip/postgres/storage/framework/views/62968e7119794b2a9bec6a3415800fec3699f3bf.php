<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>


           <br>
           <h2 class="text-center">
        <img  src="<?php echo asset('images/perfil-del-usuario.png'); ?>" alt="usuario" width="50" height="50" style=" opacity:75%">
        &nbsp
        Editar datos del usuario: <?php echo e($usuario->username); ?></h2>
           <div class="form-floating mb-2 mx-auto"
    style="font-size:16px; margin-left: 17px; width: 700px;  "><br>

           <form action="<?php echo e(route('usuarios.update', $usuario->id)); ?>" method="post" class="form-horizontal" >
                      <?php echo csrf_field(); ?>
					  <?php echo method_field('PUT'); ?>
				<div class="card">
					
<div class="card-header card-header-primary">
 <label for="name" class="col-sm-2  col-form-label"style="margin-left: 5px;">
                    <img  src="<?php echo asset('images/usuario-nombre.png'); ?>" alt="usuario" width="17" height="17" style=" opacity:85%">
                    Nombre :</label></div>
<input type="text" class="form-control" name="name" value="<?php echo e($usuario->name); ?>" autofocus>

<div class="card-header card-header-primary">
 <label for="email" class="col-sm-4 col-form-label"style="margin-left: 5px;">
          <img  src="<?php echo asset('images/email.png'); ?>" alt="usuario" width="23" height="23" style=" opacity:75%">
Correo electrónico</label></div>
                  <input type="email" class="form-control" name="email" value="<?php echo e(old('email', $usuario->email)); ?>">

                  <div class="card-header card-header-primary">
<label for="username" class="col-sm-4  col-form-label"style="margin-left: 5px; ">
          <img  src="<?php echo asset('images/usuario-nombre.png'); ?>" alt="usuario" width="17" height="17 style=" opacity:85%">
          Nombre de usuario:</label></div>
<input type="text" class="form-control" name="username" value="<?php echo e($usuario->username); ?>">


<div class="card-header card-header-primary">
<label for="password" class="col-sm-2 col-form-label"style="margin-left: 5px; ">
<img  src="<?php echo asset('images/contrasena.png'); ?>" alt="usuario" width="23" height="23" style=" opacity:75%">Contraseña</label>
</div>
<input type="password" class="form-control" name="password" value="">


 <!--Footer-->
 <div class="card-footer ml-auto mr-auto text-center">
              <button type="submit" class="btn btn-success" style="font-size: 21px; margin-top:10px">Actualizar</button>
            </div></div>          </div>
            <!--End footer-->
          </div>
        </form>

<?php endif; ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoResidencia\postgres\resources\views/admin/edit.blade.php ENDPATH**/ ?>