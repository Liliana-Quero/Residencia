<nav class="navbar navbar-expand-lg bg-green"  style="background-color:#7ebf7a; font-size: 21px;" >

  <div class="container-fluid"  >
    <a class="navbar-brand" href="#">
      <img src="<?php echo asset('images/LogoCY-PNG.png'); ?>" alt="Logo" width="190" height="70" class="d-inline-block align-text-top">
    </a>
    <div class="navbar-brand mb-0 h1" style="color:#144212;font-size: 27px;">  &nbsp COOPERATIVA YOLOMECATL</div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
            </button>
            <div  class="collapse navbar-collapse" id="navbarSupportedContent" style="color:#144212;">


  </div></nav><br>


<?php $__env->startSection('content'); ?>
<div class="mx-auto" style="width: 400px; font-size:18px" >


    <form action="/register" method="POST">
        <?php echo csrf_field(); ?>
        <h1>Registro</h1>
  <div class="form-floating mb-3">
        <input type="email" placeholder="nombre@ejemplo.com" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        <label for="exampleInputEmail1" class="form-label">Correo electrónico</label>

  </div>
  <div class="form-floating mb-3">
        <input type="text" placeholder="nombre de usuario" name="username" class="form-control" id="exampleInputPassword1">
        <label for="exampleInputPassword1" class="form-label">Usuario</label>
  </div>
  <div class="form-floating mb-3">
    <input type="password" placeholder="contraseña" name="password" class="form-control" id="exampleInputPassword1">
    <label for="exampleInputPassword1" class="form-label">Contraseña</label>
  </div>
  <div class="form-floating mb-3">
    <input type="password" placeholder="repetir contraseña" name="password_confirmation" class="form-control" id="exampleInputPassword1">
    <label for="exampleInputPassword1" class="form-label">Confirmar Contraseña</label>
  </div>
  <button type="submit" class="btn btn-primary">Registrarse</button>
  <!--<div class="mb-3">
            <a href="/login">Ya tienes cuenta</a>
        </div>-->
</form>

    <?php $__env->stopSection(); ?>
</div>

<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoResidencia\postgres\resources\views/auth/register.blade.php ENDPATH**/ ?>