<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>
<br>
<h1 class="text-center">
        &nbsp
        MI PERFIL </h1>
<br>
<div class="container">
  <div class="row">
    <div class="col">
     <img  src="<?php echo asset('images/PERFIL.png'); ?>" alt="usuario" width="280" height="280" style=" opacity:75%">

    </div>
    <div class="col">
        <br>
        <h4>Detalles del perfil:</h4><br>
    <div class="form-floating mb-3 mx-auto" style="font-size:22px;">
        <img  src="<?php echo asset('images/usuario-nombre.png'); ?>" alt="usuario" width="25px" height="25" style=" opacity:95%">
        Nombre: <?php echo e(auth()->user()->name); ?>

    </div>

    <div class="form-floating mb-3 mx-auto" style="font-size:22px;  ">
        <img  src="<?php echo asset('images/email.png'); ?>" alt="usuario" width="32px" height="32px" style=" opacity:85%">
            Correo Electrónico: <?php echo e(auth()->user()->email); ?>


  </div>

  <div class="form-floating mb-3 mx-auto" style="font-size:22px; ">
        <img  src="<?php echo asset('images/usuario-nombre.png'); ?>" alt="usuario" width="25" height="25" style=" opacity:95%">
            Rol: <?php echo e(auth()->user()->role); ?>


</div>

<div class="form-floating mb-3 mx-auto" style="font-size:22px; ">
        <img  src="<?php echo asset('images/usuario-nombre.png'); ?>" alt="usuario" width="25" height="25" style=" opacity:95%">
    Nombre de Usuario: <?php echo e(auth()->user()->username); ?>


  </div>




    </div></div></div>

<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endif; ?>



<?php if(auth()->guard()->guest()): ?>
<h1>PANEL PROYECTO</h1>
<p class="lead">Para ver el contenido, tienes que <a href="/login"> iniciar sesión.</a> </p>
<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php endif; ?>
    <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin-app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoResidencia\postgres\resources\views/auth/perfil.blade.php ENDPATH**/ ?>