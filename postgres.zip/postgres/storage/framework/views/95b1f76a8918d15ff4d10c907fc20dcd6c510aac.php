<!doctype html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <title>Iniciar Sesión</title>
    <link rel="stylesheet" href="<?php echo e(url('assets/css/bootstrap.min.css')); ?>" >
    <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <link href="<?php echo url('assets/css/app.css'); ?>" rel="stylesheet">
    <style>
        body{
            font-size: 18px;
            width: 350%;

            display:block;
            align-items: center;
            justify-content: center;
        }
        .form-container{
            width: 1350px;
        }
        </style>

</head>
<body>
    <main class="form-container">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script src="<?php echo url('assets/js/bootstrap.bundle.min.js'); ?>"></script>
<?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  </body>
</html>
<?php /**PATH C:\xampp\htdocs\proyectoResidencia\postgres\resources\views/layouts/auth-master.blade.php ENDPATH**/ ?>