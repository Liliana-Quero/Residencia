<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
        


        h1{
            text-align: center;
            font: 2rem;
            color: blue;
            font-family: sans-serif;

        }
        table{
            align-items: center;
            font: 2rem;
            border-spacing: 4px;
            border-color: black; 
            font-family: sans-serif;
            border-top: black;
            width: 900px;
            height: 100px;
            text-align: center;
            border-spacing: 0 ; 

        }
        
        tr{
            border: 0.01em solid #000;
            
        }
        th{
            border: 0.01em solid #000;

        }
        td{
            border: 0.01em solid #000;

        }
        nav{
            
            text-align: center;
            color: gray;
        }
    </style>


</head>

<body>
<nav>
    Cooperativa Yolomecatl, S.C. de A.P. de R.L. de C.V.
  <br>

    </nav>
    <div>
        <br><br>
        <h1>Listado:</h1>
        <h4>Sucursal:</h4>
        <h4>Trimestre:</h4>
        <h4>Tópico:</h4>
    </div>
    <div style="font-size: 10px;  overflow-y: hidden  " >
    

    <table id="usuarios" name="usuarios" class=" table table-hovertable table-striped table-bordered table-hover text-center"  style="font-size: 11px;  text-align: -webkit-center;  overflow-y: hidden;  vertical-align: middle;" >
    <thead   style="background-color:#7ebf7a; vertical-align: middle; " class="text-align:center">
                                    <tr style="font-size: 11px;">
                                        <th>No.</th>
                                        <th>&nbsp;Nombre&nbsp;</th>
                                        <th>&nbsp;Número de Socio&nbsp;</th>
                                        <th>Referencia de crédito</th>
                                        <th >&nbsp;Sucursal&nbsp;</th>
                                        <th >&nbsp;Fecha de colocación&nbsp;</th>
                                        <th>Monto</th>
                                        <th>&nbsp;Plazo para &nbsp;evidencias <text style="font-size:11px;"> (30 días naturales)</text></th>
                                        <th>&nbsp;Finalidad&nbsp;</th>
                                        <th>&nbsp;Factura&nbsp;</th>
                                        <th>&nbsp;Endoso a favor de la &nbsp;Cooperativa&nbsp;</th>
                                        <th>&nbsp;La &nbsp;garantía&nbsp; cubre el crédito&nbsp;</th>
                                        <th>&nbsp;Póliza de seguro vigente&nbsp;</th>
                                        <th>&nbsp;Seguro c/ &nbsp;Cobertura&nbsp; amplia&nbsp;</th>
                                        <th>Observaciones&nbsp;</th>
                                        <th style="color: white; background-color:darkgreen;">Cumplimiento</th>
                                        <th style="color: white; background-color:darkgreen; ">Nivel de Riesgo</th>
                                        <th style="color: white; background-color:darkgreen;">Estatus Actual</th>
                                        <th style="color: white; background-color:darkgreen;">Puntaje Nivel de Riesgo</th>

                                </tr>
                            </thead>
                            <tr >
                                    <?php $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($registro->id); ?></td>
                                    <td><?php echo e($registro->nombre_socio); ?></td>
                                    <td><?php echo e($registro->num_socio); ?></td>
                                    <td><?php echo e($registro->ref_credito); ?></td>
                                    <td></td>
                                    <td><?php echo e($registro->fecha_colocacion); ?></td>
                                    <td>&nbsp;$<?php echo e($registro->monto); ?>&nbsp;</td>
                                    <td><?php echo e($registro->plazo_evidencia); ?></td>

                                    <td><?php echo e($registro->finalidad); ?></td>
                                    <td><?php echo e($registro->factura); ?></td>

                                    <td><?php echo e($registro->endoso_a_favor_cooperativa); ?></td>
                                    <td><?php echo e($registro->garantia_cubre_credito); ?></td>
                                    <td><?php echo e($registro->poliza); ?></td>
                                    <td><?php echo e($registro->seguro); ?></td>
                                    <td><?php echo e($registro->observaciones); ?></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>

                                </tr><tr></tr> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
    </div>

</body>

</html>


<?php /**PATH C:\xampp\htdocs\proyectoResidencia\postgres\resources\views/pdf/pdf_cuestionario.blade.php ENDPATH**/ ?>