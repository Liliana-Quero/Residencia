<?php $__env->startSection('content'); ?>
<?php if(auth()->guard()->check()): ?>

<!DOCTYPE html>
<html lang="ES">
<head>
<script src="<?php echo url('assets/js/index.js'); ?>"></script>

 <meta charset="UTF-8">
 <title> Información </title>
</head>
<body>
    <br><br>
<div class="row">

        <div class="col-xs-5 col-md-9" style="font-size: 20px; ">
                    <a  style="margin-left: 29px;" class="btn btn-outline-success" href="/home" role="button">&laquo; Regresar </a></div>
                    <div class="col-md" style=" padding-left: 90px;" >
                <a style="font-size: 21px; align-items: left;" href="/revision" class="btn btn-md btn btn-success" role="button">
                <img src="<?php echo asset('images/salvar.png'); ?>" width="25" height="25" style="opacity:95%">
                Guardar </a>
                    </div>

                <h2 class="text-center">EVALUAR: </h2>
                <br><br>

                    <br>
                    <div style="font-size: 18px;  overflow-y: hidden  " >
                        <table id="usuarios" name="usuarios" class=" table table-hovertable table-striped table-bordered table-hover text-center"  style="  text-align: -webkit-center;  overflow-y: hidden;  vertical-align: middle;" ><br>
                                <thead  height="127px" style="background-color:#7ebf7a; vertical-align: middle; " class="text-align:center">
                                    <tr >
                                        <th>No.</th>
                                        <th>Nombre</th>
                                        <th>Número de Socio</th>
                                        <th>Referencia de crédito</th>
                                        <th >Sucursal</th>
                                        <th >Fecha de colocación</th>
                                        <th>Monto</th>
                                        <th style="width: 123px">Plazo para evidencias <text style="font-size:13px;"> (30 días naturales)</text></th>
                                        <th>Finalidad</th>
                                        <th>Factura</th>
                                        <th>Endoso a favor de la Cooperativa</th>
                                        <th>La garantía cubre el crédito</th>
                                        <th>Póliza de seguro vigente</th>
                                        <th>Endoso a favor de la Cooperativa</th>
                                        <th>Seguro c/ Cobertura amplia</th>
                                        <th>Observaciones</th>

                                </tr>
                            </thead>


                                <tr height="70px" style="  text-align: -webkit-center; font-size: 15px;">
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td>

</td>
                                    <td><input type="date" style="width: 107px; height:30px; "></td>
                                    <td><input type="number" style="width: 92px;  height:30px;"></td>
                                    <td><input type="date" style="width: 107px; height:30px; "></td>

                                    <td><textarea style="width: 125px; "></textarea></td>
                                    <td><select class="form-select form-select-md mb-1 border border-success" style=" width: 80px; height:35px; "  aria-label=".form-select-lg example">
                    <option selected>   </option>
                    <option value="1">SI</option>
                    <option value="2">NO</option>
                    <option value="3">N/A</option>
                    </select></td>

                    <td><select class="form-select form-select-md mb-1 border border-success" style=" width: 80px; height:35px; "  aria-label=".form-select-lg example">
                    <option selected>   </option>
                    <option value="1">SI</option>
                    <option value="2">NO</option>
                    <option value="3">N/A</option>
                    </select></td>
                    <td><select class="form-select form-select-md mb-1 border border-success" style=" width:80px; height:35px; "  aria-label=".form-select-lg example">
                    <option selected>   </option>
                    <option value="1">SI</option>
                    <option value="2">NO</option>
                    <option value="3">N/A</option>
                    </select></td>
                    <td><select class="form-select form-select-md mb-1 border border-success" style="width:80px; height:35px; "  aria-label=".form-select-lg example">
                    <option selected>   </option>
                    <option value="1">SI</option>
                    <option value="2">NO</option>
                    <option value="3">N/A</option>
                    </select></td>
                    <td><select class="form-select form-select-md mb-1 border border-success" style="width:80px; height:35px; "  aria-label=".form-select-lg example">
                    <option selected>   </option>
                    <option value="1">SI</option>
                    <option value="2">NO</option>
                    <option value="3">N/A</option>
                    </select></td>
                    <td><select class="form-select form-select-md mb-1 border border-success" style="width:80px; height:35px; "  aria-label=".form-select-lg example">
                    <option selected>   </option>
                    <option value="1">SI</option>
                    <option value="2">NO</option>
                    <option value="3">N/A</option>
                    </select></td>
                    <td> <textarea></textarea></td>
                                </tr>
                                <tr height="70px">
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                </tr>

                            </tbody>
                        </table>

                    </div>
                    <div class="col-xs-5 col-md-4" style="font-size: 17.5x;">
                    <div id="Layer1" style="width:700px; overflow-y: hidden ">

                            <tbody>


    </div>

</body>



    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php endif; ?>

</html>
</div>





    <?php if(auth()->guard()->guest()): ?>
        <h1>PANEL PROYECTO</h1>
        <p class="lead">Para ver el contenido, tienes que <a href="/login"> iniciar sesión.</a> </p>
        <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoResidencia\postgres\resources\views/cuestionario.blade.php ENDPATH**/ ?>