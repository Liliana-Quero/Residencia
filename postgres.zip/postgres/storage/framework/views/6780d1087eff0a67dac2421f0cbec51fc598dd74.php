<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
        h1{
            text-align: center;
            font: 2rem;
            color: blue;
            font-family: sans-serif;

        }
        table{
            align-items: center;
            font: 2rem;
            border-spacing: 6px;
            font-family: sans-serif;

        }
        nav{
            text-align: center;
            color: gray;
        }
    </style>


</head>

<body>
<nav>
    Cooperativa Yolomecatl, S.C. de A.P. de R.L. de C.V.
  <br>

    </nav>
    <div>
        <br><br>
        <h1>Listado de Usuarios</h1>
    </div>
    <div class="table-responsive"><BR>
            <table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Rol</th>
                    <th>Correo electrónico</th>
                    <th>Nombre de Usuario</th>
                 </thead>
                 <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <tr>
                    <td><?php echo e($user->id); ?></td>
                    <td><?php echo e($user->name); ?></td>
                    <td><?php echo e($user->role); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->username); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                 </tr>
            </table>
    </div>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\proyectoResidencia\postgres\resources\views/pdf/generar_pdf.blade.php ENDPATH**/ ?>