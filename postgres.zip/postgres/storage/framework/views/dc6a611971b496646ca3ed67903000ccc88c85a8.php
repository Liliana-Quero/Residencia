<!doctype html>
<html lang="en">
    <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">

    <title>Cooperativa Yolomecatl </title>

    <link href="<?php echo url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet">



    <link href="<?php echo url('assets/css/app.css'); ?>" rel="stylesheet">
</head>
<body>

    <?php echo $__env->make('layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="container" style="max-width: 1240px; margin: auto;">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script src="<?php echo url('assets/js/bootstrap.bundle.min.js'); ?>"></script>

  </body>
</html>
<?php /**PATH C:\xampp\htdocs\proyectoResidencia\postgres\resources\views/layouts/app-master.blade.php ENDPATH**/ ?>