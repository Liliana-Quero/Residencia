<?php $__env->startSection('content'); ?>
<div class="mx-auto" style="width: 400px; font-size:18px" >
            <form action="/login" method="POST" action="">
                <br>
                <?php echo csrf_field(); ?>

                <img class="mx-auto d-block" src="<?php echo asset('images/usuario.png'); ?>" alt="usuario" width="58" height="58" style=" opacity:65%">
                <br>
                <h1 class="text-center">Iniciar Sesión</h1><br>
                <?php echo $__env->make('layouts.partials.messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><br>
        <div class="form-floating mb-3 mx-auto" style="font-size:18px; width: 500px;  ">
                        <input type="text" placeholder="usuario" name="username" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" style="font-size:16px">
                        <label for="exampleInputEmail1" class="form-label"  style="font-size:16px">Usuario / Dirección de Email </label>

        </div>
        <div class="form-floating mb-3 mx-auto" style="font-size:18px; width: 500px;">
            <input type="password" placeholder="contraseña" name="password" class="form-control" id="exampleInputPassword1" style="font-size:16px">
                    <label for="exampleInputPassword1" class="form-label" style="font-size:16px">Contraseña</label>
                </div>
         <button type="submit" class="btn btn-primary d-block mx-auto"  style="font-size: 22px;">
         <img  src="<?php echo asset('images/ingresar.png'); ?>" alt="usuario" width="28" height="28" style=" opacity:95%">
         Entrar</button>

        </form>


</div>
    <?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.auth-master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\proyectoResidencia\postgres\resources\views/auth/login.blade.php ENDPATH**/ ?>