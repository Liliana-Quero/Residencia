<p class="mt-5 mb-3 text-muted">&copy; <?php echo e(date('Y')); ?></p>
<?php /**PATH C:\xampp\htdocs\proyectoResidencia\postgres\resources\views/auth/partials/copy.blade.php ENDPATH**/ ?>