@extends('layouts.admin-app')
@section('content')
@auth
<div class="row">

        <div class="col-md" >
        <br>
                <label>

                </label>

        </div>
        <div class="col-md">
        </div>
                    <div class="col-md">
                   <br> <a href="/register"><button class="btn btn-success" style="font-size: 20px; ">
                   <img  src="{!! asset('images/agregar-usuario.png') !!}" alt="usuario" width="29" height="28" style=" opacity:75%">

                   Añadir Nuevo Usuario</button></a>
                    </div>
        <h2 class="text-center"> USUARIOS:</h2>
<br>
<div class="row" style="padding: left 50px;">
    <div class="col-md-3 col-md-4 col-sm-14 col-xs-4">

      @include('admin.search')

      </div>
</div><br>
</div>
<div class="row">
        <div class="col-md" >
        <br>
                <label>
                </label>

        </div>
        <div class="col-md">
        </div>
                    <div class="col-md" style="padding-left: 600px;">
                   <br> <a href="{{route('usuarios.create') }}" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm">
        {{__('PDF') }}
      </a>
                    </div>
<div class="row" style="padding: left 50px;">

    <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="table-responsive"><BR>
            <table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Rol</th>
                    <th>Correo electrónico</th>
                    <th>Nombre de Usuario</th>
                 </thead>
                 @foreach ($usuarios as $usuario)
                 <tr>
                    <td>{{ $usuario->id}}</td>
                    <td>{{ $usuario->name}}</td>
                    <td>{{ $usuario->role}}</td>
                    <td>{{ $usuario->email}}</td>
                    <td>{{ $usuario->username}}</td>

                    <td class="text-center">
                        <a href="{{URL::action('UserController@edit', $usuario->id)}}">
                            <button class="btn btn-info" style="-WEBKIT-TEXT-STROKE: thin;">
                            <img  src="{!! asset('images/editar-texto.png') !!}" alt="usuario" width="22" height="21" style=" opacity:75%">
                            Editar</button></a>

                         <button class="btn btn-danger btnEliminar " data-id="{{ $usuario->id}}" style="-WEBKIT-TEXT-STROKE: thin;">
                         <img  src="{!! asset('images/boton-salir.png') !!}" alt="usuario" width="29" height="28" >
                         Eliminar</button>
                            <form action="{{ url('/admin/usuarios', ['id'=> $usuario->id ]) }}" method="post" id="FormEli_{{ $usuario->id}}">
                            @csrf


                        <input type="hidden" name="id" value="{{$usuario->id}}">
                        <input type="hidden" name="_method" value="delete">

                        </form>

        </td>
				</tr>
				@include('modal')
				@endforeach
			</table>
		</div>
		{{$usuarios->render()}}
    </div>
</div>


    @include('layouts.partials.footer')

        @endauth





    @guest
        <h1>PANEL PROYECTO</h1>
        <p class="lead">Para ver el contenido, tienes que <a href="/login"> iniciar sesión.</a> </p>
        @include('layouts.partials.footer')

        @endguest
    </div>
@endsection


