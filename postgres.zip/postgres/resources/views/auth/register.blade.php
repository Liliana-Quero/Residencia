@extends('layouts.admin-app')
@section('content')
@auth
<br>

<div class="mx-auto" style="width: 700px; font-size:18px" >


    <form action="/register" method="POST">
        @csrf
        <h1 class="text-center">
        <img  src="{!! asset('images/agregar-usuario.png') !!}" alt="usuario" width="59" height="58" style=" opacity:75%">
        &nbsp
        REGISTRAR NUEVO USUARIO:</h1><br>


  <div class="form-floating mb-3">
        <input type="email" placeholder="nombre@ejemplo.com" name="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
        <label for="exampleInputEmail1" class="form-label">Correo electrónico</label>

  </div>
  <div class="form-floating mb-3">

<input type="text" placeholder="nombre" name="name" class="form-control" id="exampleInputPassword1" >
<label for="exampleInputPassword1" class="form-label">Nombre</label>

</div>
<div class="form-floating mb-3">

<input type="text" placeholder="nombre" name="role" class="form-control" id="exampleInputPassword1" >
<label for="exampleInputPassword1" class="form-label">Rol</label>

</div>
  <div class="form-floating mb-3">
        <input type="text" placeholder="nombre de usuario" name="username" class="form-control" id="exampleInputPassword1">
        <label for="exampleInputPassword1" class="form-label">Nombre de Usuario</label>
  </div>

  <div class="form-floating mb-3">
    <input type="password" placeholder="contraseña" name="password" class="form-control" id="exampleInputPassword1">
    <label for="exampleInputPassword1" class="form-label">Contraseña</label>
  </div>
  <div class="form-floating mb-3">
    <input type="password" placeholder="repetir contraseña" name="password_confirmation" class="form-control" id="exampleInputPassword1">
    <label for="exampleInputPassword1" class="form-label">Confirmar Contraseña</label>
  </div><BR>
  <button type="submit"  class="btn btn-primary d-block mx-auto" style="font-size: 21px;">REGISTRAR</button>
  <!--<div class="mb-3">
            <a >Ya tienes cuenta</a>
        </div>-->
</form>

    @endsection
</div>
@endauth


@guest
<h1>PANEL PROYECTO</h1>
<p class="lead">Para ver el contenido, tienes que <a href="/login"> iniciar sesión.</a> </p>
@include('layouts.partials.footer')

@endguest
