<footer style="width:1260px" class="text-center text-lg-start bg-white text-muted footer flex-expand-lg  py-4 d-flex flex-lg-column ">
  <section class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom">
  </section>
     <div class=" container text-center p-3 " style=" background-color: rgba(0, 0, 0, 0.025); font-size:13px; font-family:Poppins, Helvetica;">
    <br>
    Cooperativa Yolomecatl, S.C. de A.P. de R.L. de C.V.
  </div>

</footer>

