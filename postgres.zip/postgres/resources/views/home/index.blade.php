@extends('layouts.app-master')
@section('content')

<html lang="ES">
<head>
 <meta charset="UTF-8">
 <title> Index </title>
 <script src="{!! url('assets/js/index.js') !!}"></script>

</head>
<body>
<div class=" p-3 rounded">

        @auth

        <h1 style="text-align: center;">INICIO
        <p class="lead" >Usuario  {{auth()->user()->name ?? auth()->user()->username}},
            para seleccionar el Tópico, tienes que escoger la Sucursal y el Trimestre.</p></h1>

        <div class="row ">
        <div class="col-xs-5 col-md-6" style="font-size: 14px; ">



        <form>


        <br> <p>
            <H2>
            <img src="{!! asset('images/sucursal.png') !!}" width="26" height="26" style="opacity:65%">

                Escoge la sucursal:</H2>
        <select name="select1" onchange= "validar(this.form) "  id="select1" class="form-select form-select-lg mb-3" style="width:90%" aria-label=".form-select-lg example" required>
        <option selected disabled="disabled">Seleccionar Sucursal</option>
            <option value="pgsql_001_Yolomecatl">001 Yolomecatl (Oficinas)</option>
            <option value="pgsql_002_Nochixtlan">002 Nochixtlan (Oficinas)</option>
            <option value="pgsql_003_Oaxaca_Arteaga">003 Oaxaca/Arteaga (Oficinas)</option>
            <option value="pgsql_005_Huajuapan">005 Huajuapan (Oficinas)</option>
            <option value="pgsql_006_Nicananduta">006 Nicananduta (Oficinas)</option>
            <option value="pgsql_007_Coixtlahuaca">007 Coixtlahuaca (Oficinas)</option>
            <option value="pgsql_008_Tepelmeme">008 Tepelmeme (Oficinas)</option>
            <option value="pgsql_010_Tezoatlan">010 Tezoatlan (Oficinas)</option>
            <option value="pgsql_012_Ajalpan">012 Ajalpan (Oficinas)</option>
                                    </select></p>

        <br><p>
         <H2>
         <img src="{!! asset('images/trimestre.png') !!}" width="30" height="30" style="opacity:65%">

            Escoge el trimestre:</H2>
        <select name="select2" onchange = "habilitar(this.form)"  id="select2" class="form-select form-select-lg mb-3" style="width:90%" aria-label=".form-select-lg example" required>
        <option selected disabled="disabled">Seleccionar Trimestre</option>
        <option value="1111">Trimestre 1</option>
        <option value="2222">Trimestre 2</option>
        <option value="3333">Trimestre 3</option>
        </select></p>
            </div>


        <div class="col-xs-5 col-md-4" style="font-size: 16px;">
        <br><p>
        <H2>
        <img src="{!! asset('images/topicos.png') !!}" width="30" height="30" style="opacity:65%">
            Escoge el tópico:</H2>
        <select name="select3" disabled="disabled" onchange = "habilitar2(this.form)"   id="select3" class="form-select form-select-lg mb-3" style="width:140%" aria-label=".form-select-lg example" >
        <option selected disabled="disabled">Seleccionar Tópico</option>
        <option value="11">Creditoauto</option>
        <option value="12">Tópico 2</option>
        <option value="13">Tópico 3</option>
        <option value="14">Tópico 4</option>
        <option value="50">Tópico 5</option>
        <option value="60">Tópico 6</option>
        <option value="70">Tópico 7</option>
        <option value="80">Tópico 8</option>
        <option value="90">Tópico 9</option>
        <option value="100">Tópico 10</option>
        </select></p>

        <br>
        <button onclick="(function(){location.reload();})" class="btn-lg btn-block btn btn-success"  style="width:60%; font-size: 16px; align-items: center ; justify-content: rigth;">
        <img src="{!! asset('images/limpiar.png') !!}" width="30" height="30" style="opacity:65%">
LIMPIAR DATOS</button>

    </div>

    </div>

</form>
<script>

    function habilitar2() {
    select2 = document.getElementById ("select3").value;
    select3 = document.getElementById ("select3").value;

    val=0;

    if(select3 == ""){
        val++;
    }
    if(select3 == ""){
        val++;
    }

    if(val == 0){
        document.getElementById("boton").disabled = false;
    } else {
        document.getElementById("boton").disabled = true;
    }
}
document.getElementById("select3").addEventListener("change", habilitar2);
document.getElementById("select3").addEventListener("change", habilitar2);
document.getElementById("boton").addEventListener("click", () =>{

}); </script>
<form>
<div class="text-center">
        <br><br>


<input type="button" name="boton" id="boton"   onclick="location.href='/cuestionario';" class="btn-lg btn-block btn btn-success"
         role="button" style="width:60%; font-size: 21px; align-items: center; justify-content: center;"
         value="BUSCAR &raquo;" disabled/>

</div>
</form>
        @include('layouts.partials.footer')

        @endauth
</div>
</body></html>

        @guest
        <h1>PANEL PROYECTO</h1>
        <p class="lead">Para ver el contenido, tienes que <a href="/login"> iniciar sesión.</a> </p>
        @include('layouts.partials.footer')

        @endguest
    </div>
@endsection
