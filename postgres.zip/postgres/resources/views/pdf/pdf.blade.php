<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
        .titulo{
            text-align: center;
            font: 2rem;
            color: blue;

        }
    </style>
</head>
<body>
    <div>
        <h1>Listado de Usuarios</h1>
    </div>
    <div class="table-responsive"><BR>
            <table class="table table-striped table-bordered table-condensed table-hover">
                <thead>
                    <th>ID</th>
                    <th>Nombre</th>
                    <th>Rol</th>
                    <th>Correo electrónico</th>
                    <th>Nombre de Usuario</th>
                 </thead>
                 @foreach ($data as $da)
                 <tr>
                    <td>{{ $da->id}}</td>
                    <td>{{ $da->name}}</td>
                    <td>{{ $da->role}}</td>
                    <td>{{ $da->email}}</td>
                    <td>{{ $da->username}}</td>
                    @endforeach
                 </tr>
            </table>
    </div>

</body>
</html>
