<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateSucTrimTop extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('suc_trim_top', function (Blueprint $table) {
            $table->id();
            $table->foreignId('sucursal_trimestre_id')->constrained('trimestre');
            $table->foreignId('sucursal_topicos_id')->nullable()->constrained('topicos');
            $table->foreignId('trimestre_topicos_id')->nullable()->constrained('topicos');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('suc_trim_top');
    }
}
