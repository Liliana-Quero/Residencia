
'System',
            'last_name'  => 'Administrator',
            'username'   => 'admin',
            'email'      => 'postmaster@domain.com',
            'password'   =>  Hash::make('secret')
        ]);
    }

}
